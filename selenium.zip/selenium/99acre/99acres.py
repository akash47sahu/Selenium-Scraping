from selenium import webdriver
import time
from selenium.webdriver import Firefox
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import re
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
import xlrd
from xlrd import open_workbook
import openpyxl
from selenium.webdriver.support.select import Select
import numpy as np
from selenium.webdriver.firefox.options import Options



driver = webdriver.Firefox ()

Dict = {'i_d_3': 'jajofa2684@inmail92.com',
        'password_3' : 'akash47@',
        'i_d_1': 'shubham.sh5512@gmail.com',
        'password_1' : 'Housing@12345',
        'i_d_6': 'shubham.sh5511@gmail.com',
        'password_6' : 'Housing@12345',
        'i_d_0': 'shubham.sh5566@gmail.com',
        'password_0' : 'Housing@12345',
        'i_d_4': 'shubham.sh5588@gmail.com',
        'password_4' : 'Housing@12345'
        }


delays = [2, 4, 6, 8, 10]
delay = np.random.choice(delays)


url = "https://www.99acres.com/"

def acre():
    prop_list = []


    driver.get(url)



    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CLASS_NAME, "iconS.ham-Icon"))).click()
    time.sleep(2)
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CLASS_NAME, "mmWrap.Login.f14"))).click()
    time.sleep(2)
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.NAME, "username"))).send_keys(Dict['i_d_0'])
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.ID, "loginSubmit"))).click()
    time.sleep(2)
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.NAME, "password"))).send_keys(Dict['password_0'])
    time.sleep(2)
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.ID, "loginSubmit"))).click()
    time.sleep(8)


    loc = "properties.xlsx"

    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)
    sheet_len = sheet.nrows


 ## loop to get and open filter_Url from properties.xlsx
    for i in range(2, sheet_len):
        count = 0
        id_count = 0
        filter_url = sheet.cell_value(i, 0)
        print(str(i) + '>>' + filter_url)

        driver.get(filter_url)
        time.sleep(3)

        # for residencial properties on rent/pg
        prop_url = driver.find_elements_by_class_name('srpTuple__tupleTable')
        print('prop_url',prop_url)
        for block in prop_url:
            elements = block.find_elements_by_tag_name("a")
            print('elements',elements)
            for elem in elements:
                prop_list.append(elem.get_attribute("href"))
        length = len(prop_list)
        print(prop_list)
        print('No. of Properties : ', length)
        print('Q')
        # for commercial properties
        if length == 0:

            prop_url = driver.find_elements_by_class_name('NpsrpTuple__npsrpCard')
            print('prop_url',prop_url)
            for block in prop_url:
                elements = block.find_elements_by_tag_name("a")
                print('elements',elements)
                for elem in elements:
                    prop_list.append(elem.get_attribute("href"))
            length = len(prop_list)
            print(prop_list)
            print('No. of Properties : ', length)

## loop to open property url from list of urls
        for j in range(1, length):

            property = prop_list[j]
            print(j, ",", property)
            count += 1

            delays = [2, 4, 6, 8, 10]
            delay = np.random.choice(delays)


            wb_obj = openpyxl.load_workbook('bangalore.xlsx')
            sheet_obj = wb_obj.active

            len_excel = sheet_obj.max_row + 1
            print('len_excel', len_excel)

            driver.get(property)
            time.sleep(delay)
            c1 = sheet_obj.cell(row=len_excel, column=1)
            c1.value = property
            c33 = sheet_obj.cell(row=len_excel, column=17)
            c33.value = filter_url

            try:
                Dealer_N = driver.find_element_by_class_name('component__primaryInfo').text
                Dealer_Name = Dealer_N.split('\n')[0]
                print('Dealer_Name :',Dealer_Name)
                c2 = sheet_obj.cell(row=len_excel, column=2)
                c2.value = Dealer_Name
            except Exception as e:
                print('Dealer_Name not available',e)
                c2 = sheet_obj.cell(row=len_excel, column=2)
                c2.value = 'Not  Available'
            try:
                posted_on = driver.find_element_by_id('postedOnAndByLabel').text

                print('Posted By and On :', posted_on)
                c3 = sheet_obj.cell(row=len_excel, column=3)
                c3.value = posted_on
            except Exception as e:
                print('Posted By and On not available',e)
                c3 = sheet_obj.cell(row=len_excel, column=3)
                c3.value = 'Not  Available'
            try:
                print('looking for no.')
                driver.find_element_by_id('contactDealerBtn').click()
                time.sleep(delay)

                phn1 = driver.find_element_by_xpath(
                    '/html/body/div[1]/div/div[7]/div[1]/div[2]/div[1]/div[1]/div/div[2]').text
                contact_dealer = phn1.split(',')[0]
                contact_dealer_email = phn1.split(',')[1]
                print(contact_dealer)
                print(contact_dealer_email)
                c4 = sheet_obj.cell(row=len_excel, column=4)
                c4.value = contact_dealer
                c5 = sheet_obj.cell(row=len_excel, column=5)
                c5.value = contact_dealer_email
            except Exception as e:
                print('Not found',e)
                c4 = sheet_obj.cell(row=len_excel, column=4)
                c4.value = 'Not  Available'
                c5 = sheet_obj.cell(row=len_excel, column=5)
                c5.value = 'Not  Available'
            try:
                not_allowed = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.CLASS_NAME, "component__errorMsg"))).text
                if not_allowed[:4] == 'Your':
                    c4 = sheet_obj.cell(row=len_excel, column=4)
                    c4.value = 'You have already contacted the maximum advertisers allowed for this week.,Login with another i.d '
                    c5 = sheet_obj.cell(row=len_excel, column=5)
                    c5.value = 'You have already contacted the maximum advertisers allowed for this week.,Login with another i.d '
                    print('You have already contacted the maximum advertisers allowed for this week.,Login with another i.d ')
                else:
                    pass
            except Exception as e:
                print(e)
            try:
                reci = driver.find_element_by_id('headerDescription').text
                Residential_type = reci.split('for')[0]
                print('Residential_type',Residential_type)
                c6 = sheet_obj.cell(row=len_excel, column=6)
                c6.value = Residential_type

            except Exception as e:
                print('Residential_type not available',e)
                c6 = sheet_obj.cell(row=len_excel, column=6)
                c6.value = 'Not  Available'

            try:
                addrs = driver.find_element_by_class_name('component__pdPropAddress').text
                print(addrs)
                c7 = sheet_obj.cell(row=len_excel, column=7)
                c7.value = addrs
            except Exception as e:
                print('addrs not available',e)
                # c7 = sheet_obj.cell(row=len_excel, column=7)
                # c7.value = 'Not  Available'
            try:
                address = driver.find_element_by_id('address').text

                print('Address:', address)
                c7 = sheet_obj.cell(row=len_excel, column=7)
                c7.value = address
            except Exception as e:
                print('Address not available',e)
                # c7 = sheet_obj.cell(row=len_excel, column=7)
                # c7.value = 'Not  Available'


            try:
                city_str = address.split()
                city = city_str[-1]
                c8 = sheet_obj.cell(row=len_excel, column=8)
                c8.value = city
                print(city)
            except Exception as e:
                print('city not available',e)
                # c8 = sheet_obj.cell(row=len_excel, column=8)
                # c8.value = 'Not  Available'
            try:
                city_str = addrs.split()
                city = city_str[-1]
                c8 = sheet_obj.cell(row=len_excel, column=8)
                c8.value = city
                print(city)
            except Exception as e:
                print('city not available',e)
                # c8 = sheet_obj.cell(row=len_excel, column=8)
                # c8.value = 'Not  Available'
            try:
                # lable = driver.find_element_by_xpath('/html/body/div[1]/div/div[4]/div[1]/div[2]/div[1]/div').text
                lable = driver.find_element_by_class_name(
                    'component__label.component__Platinum.component__pdFixWidth').text

                print('Lable :', lable)
                c9 = sheet_obj.cell(row=len_excel, column=9)
                c9.value = lable
            except Exception as e:
                print('Lable not available', e)
                c9 = sheet_obj.cell(row=len_excel, column=9)
                c9.value = 'Not  Available'
            try:
                area = driver.find_element_by_id('builtupArea_span').text

                print('Built Up area:',area)
                c10 = sheet_obj.cell(row=len_excel, column=10)
                c10.value = area
            except Exception as e:
                print('Built Up area not available',e)
                c10 = sheet_obj.cell(row=len_excel, column=10)
                c10.value = 'Not  Available'
            try:
                property_no = driver.find_element_by_class_name('component__listed').text
                Properties_Listed = property_no[-1]
                print('Properties_Listed',Properties_Listed)
                c11 = sheet_obj.cell(row=len_excel, column=11)
                c11.value = Properties_Listed
            except Exception as e:
                print('Properties_Listed not available',e)
                c11 = sheet_obj.cell(row=len_excel, column=11)
                c11.value = 'Not  Available'
            try:
                residence_type = driver.find_element_by_id('headerDescription').text
                print('residence_type', residence_type)
                c12 = sheet_obj.cell(row=len_excel, column=12)
                c12.value = residence_type
            except Exception as e:
                print('residence_type not available', e)
                c12 = sheet_obj.cell(row=len_excel, column=12)
                c12.value = 'Not  Available'
            try:
                rent = driver.find_element_by_id('pdPrice').text

                print('Rent:',rent)
                c13 = sheet_obj.cell(row=len_excel, column=13)
                c13.value = rent
            except Exception as e:
                print('Rent not available',e)
                c13 = sheet_obj.cell(row=len_excel, column=13)
                c13.value = 'Not  Available'
            try:
                room_bath = driver.find_element_by_id('bedWash').text
                rooms = room_bath.split(' ')[0]
                print('rooms', rooms)
                c14 = sheet_obj.cell(row=len_excel, column=14)
                c14.value = rooms

            except Exception as e:
                print('no. of rooms not available',e)
                c14 = sheet_obj.cell(row=len_excel, column=14)
                c14.value = 'Not  Available'
            try:
                title_city = WebDriverWait(driver, 2).until(
                    EC.element_to_be_clickable((By.CLASS_NAME, "ProjectInfo__imgBox1.title_bold"))).text
                title = title_city.split('\n')[0]
                City = title_city.split('\n')[1]
                print('Title :', title)
                print('City :', City)
                c16 = sheet_obj.cell(row=len_excel, column=16)
                c16.value = title
                c17 = sheet_obj.cell(row=len_excel, column=17)
                c17.value = City
            except Exception as e:
                print('title not available', e)
                c16 = sheet_obj.cell(row=len_excel, column=16)
                c16.value = 'Not Available'
                c17 = sheet_obj.cell(row=len_excel, column=17)
                c17.value = 'Not Available'

            try:

                pri = driver.find_element_by_class_name('unitOptions__propDetailsCrdWrap').text

                price1 = re.search('Price\n(.*)\n', pri).group(1)
                area1 = pri.split('Area')[1].replace('\n', ' ')
                print('Builder price :', price1)
                print('Super-builtup Area :', area1)
                c18 = sheet_obj.cell(row=len_excel, column=18)
                c18.value = price1
                c19 = sheet_obj.cell(row=len_excel, column=19)
                c19.value = area1
            except Exception as e:
                # print('Builder,price and area  not available',e)
                c18 = sheet_obj.cell(row=len_excel, column=18)
                c18.value = 'Not Available'
                c19 = sheet_obj.cell(row=len_excel, column=19)
                c19.value = 'Not Available'
            try:
                builder = driver.find_element_by_xpath(
                    '/html/body/div[1]/div/div[3]/div[2]/div/div/div/div[2]/div[1]/button')
                builder.click()
                time.sleep(delay)
                WebDriverWait(driver, 3).until(EC.element_to_be_clickable(
                    (By.XPATH, "/html/body/div[1]/div/div[1]/div[1]/div[4]/form/div[2]/div[4]/input"))).click()
            except Exception as e:
                print('Contact builder not available', e)
            try:
                developed_by = driver.find_element_by_class_name('section_header_bold.spacer4').text
                print('Developed by :', developed_by)
                c20 = sheet_obj.cell(row=len_excel, column=20)
                c20.value = developed_by
            except Exception as e:
                print('Developed by not available', e)
                c20 = sheet_obj.cell(row=len_excel, column=20)
                c20.value = 'Not Available'
            try:
                unit_option = driver.find_element_by_class_name('unitConfigPlate__propDetailsTags').text
                print('Unit Option :', unit_option)
                c21 = sheet_obj.cell(row=len_excel, column=21)
                c21.value = unit_option
            except Exception as e:
                print('Unit Option   not available', e)
                c21 = sheet_obj.cell(row=len_excel, column=21)
                c21.value = 'Not Available'
            try:
                resale = driver.find_elements_by_class_name('xidHeading__headRight')
                resale_list = []
                for ele in resale:
                    resale_list.append(ele.text)
            except Exception as e:
                print(e)
            try:
                Resale = resale_list[0]
                resale_pro = Resale.split('Properties')[0]
                re_str = resale_pro.split()
                Resale_Properties = re_str[-1]
                print(Resale_Properties)
                c22 = sheet_obj.cell(row=len_excel, column=22)
                c22.value = Resale_Properties
            except Exception as e:
                print(' Resale  properties not available', e)
                c22 = sheet_obj.cell(row=len_excel, column=22)
                c22.value = 'Not Available'
            try:
                Lease = resale_list[1]
                lease_pro = Lease.split('Properties')[0]
                lea_str = lease_pro.split()
                Lease_Properties = lea_str[-1]
                print(Lease_Properties)
                c23 = sheet_obj.cell(row=len_excel, column=23)
                c23.value = Lease_Properties
            except Exception as e:
                print('lease properties not available', e)

                c23 = sheet_obj.cell(row=len_excel, column=23)
                c23.value = 'Not Available'


            finally:
                wb_obj.save("bangalore.xlsx")

# to switch login id after 7 properties scraped
            if count % 7 == 0:
                if id_count >6:
                    continue
                id_count += 1
                new_id = 'i_d_'+str(id_count)
                new_pass = 'password_'+str(id_count)
                print('new_id',new_id)
                print(Dict[new_id])
                print('new_pass',new_pass)
                print(Dict[new_pass])
                driver.get(url)
                time.sleep(4)
                try:
                    WebDriverWait(driver, 3).until(EC.element_to_be_clickable((By.ID, "hmcontainer"))).click()
                except Exception as e:
                    print(e)
                try:
                    WebDriverWait(driver, 3).until(
                        EC.element_to_be_clickable((By.CLASS_NAME, "iconS.ham-Icon"))).click()
                except Exception as e:
                    print(e)
                WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.CLASS_NAME, "mmWrap.Login.f14"))).click()
                element = driver.find_element_by_xpath('/html/body/div[2]/div[2]/div[1]/header/div[1]/nav/div[2]/div/div/div/a[6]')
                driver.execute_script("arguments[0].click();", element)
                time.sleep(delay)
                try:
                    WebDriverWait(driver, 2).until(EC.element_to_be_clickable((By.ID, "hmcontainer"))).click()
                except Exception as e:
                    print(e)
                try:
                    WebDriverWait(driver, 2).until(
                        EC.element_to_be_clickable((By.CLASS_NAME, "iconS.ham-Icon"))).click()
                    time.sleep(delay)
                except Exception as e:
                    print(e)
                time.sleep(2)
                try:
                    elem = driver.find_element_by_xpath('/html/body/div[2]/div[2]/div[1]/header/div[1]/nav/div[2]/div/a')
                    print(elem)
                    driver.execute_script("arguments[0].click();", elem)
                except Exception as e:
                    print(e)
                try:
                    WebDriverWait(driver, 2).until(EC.element_to_be_clickable((By.ID, "login"))).click()
                except Exception as e:
                    print(e)
                WebDriverWait(driver,2).until(EC.element_to_be_clickable((By.NAME, "username"))).send_keys(Dict[new_id])
                time.sleep(delay)
                WebDriverWait(driver,2).until(EC.element_to_be_clickable((By.ID, "loginSubmit"))).click()
                WebDriverWait(driver,2).until(EC.element_to_be_clickable((By.NAME, "password"))).send_keys(Dict[new_pass])
                time.sleep(delay)
                WebDriverWait(driver,2).until(EC.element_to_be_clickable((By.ID, "loginSubmit"))).click()
                time.sleep(8)



acre()




