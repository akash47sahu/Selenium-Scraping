from selenium import webdriver
import pandas as pd
import time
import csv
from multiprocessing import Process
from selenium.webdriver.chrome.options import Options
from selenium.webdriver import Firefox
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.wait import WebDriverWait
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from xlrd import open_workbook
from xlwt import Workbook
from xlutils.copy import copy
import xlwt
from xlwt import Workbook

options = webdriver.FirefoxOptions()
options.add_argument('-headless')
print("Headless Chrome Initialized on Windows OS")
# driver = webdriver.Firefox(options=options)
driver = webdriver.Firefox()
myDict = {}
list_1 = []
def basspro():

    url = "https://www.basspro.com/shop/en"
    driver.get(url)

    # wb = Workbook()
    # sheet1 = wb.add_sheet('Sheet 1')

    rb = open_workbook("BassPro_JAYBIMBAUM.xls")
    wb = copy(rb)

    sheet1 = wb.get_sheet(0)

    sheet1.write(0, 0, 'Order_no')
    sheet1.write(0, 1, 'Ordered_Date')
    sheet1.write(0, 2, 'Status')
    sheet1.write(0, 3, 'Title')
    sheet1.write(0, 4, 'Item_SKU')
    sheet1.write(0, 5, 'Quantity')
    sheet1.write(0, 6, 'Price')
    sheet1.write(0, 7, 'Subtotal')


    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CLASS_NAME, "myAccount.myaccount_signin"))).click()


    driver.implicitly_wait(3)
    driver.find_element_by_class_name("input_field.global_login_input").send_keys("JAYBIMBAUM@GMAIL.COM")
    driver.implicitly_wait(1)
    driver.find_element_by_class_name("form_input.global_login_input").send_keys("93G6q7X8")
    driver.refresh()
    driver.implicitly_wait(3)
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CLASS_NAME, "myAccount.myaccount_signin"))).click()


    driver.implicitly_wait(2)
    driver.find_element_by_class_name("input_field.global_login_input").send_keys("JAYBIMBAUM@GMAIL.COM")
    driver.implicitly_wait(1)
    driver.find_element_by_class_name("form_input.global_login_input").send_keys("93G6q7X8")
    driver.implicitly_wait(1)
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.ID, "Header_GlobalLogin_WC_AccountDisplay_links_2"))).click()
    time.sleep(8)

    # WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.ID, "WC_MyAccountCenterLinkDisplay_inputs_2"))).click()
    # view_all = driver.find_element_by_id("WC_MyAccountCenterLinkDisplay_inputs_2")
    #
    # driver.execute_script("arguments[0].click()", view_all)
    #
    # driver.implicitly_wait(2)

    # texts = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CLASS_NAME, "page-results"))).text
    #
    #
    # user = texts[texts.find("of ") + 2:].split()[0]
    # results = int(user)

    for i in range(2,22):
        try:
            print(i)
            Order_Number = ' '
            Order_Date = ' '
            Status = ' '
            title = ' '
            SKU = ' '
            quantity= ' '
            price = ' '
            subtotal = ' '

            id_text = "WC_OrderStatusDisplay_Link_2b_"+str(i)
            details = driver.find_element_by_id(id_text)

            driver.execute_script("arguments[0].click()", details)

            time.sleep(4)
            details_1 = driver.find_element_by_id("WC_OrderShipmentDetails_div_7").text

            # details_1 = driver.find_element_by_class_name("order_details_my_account").text
            details_2 = driver.find_element_by_class_name("shopcart_fullView").text
            Order_Number = details_1.split('Number:')[1].split('Order')[0].strip()
            # print('Order_Number',Order_Number)

            Order_Date = details_1.split('Date:')[1].split('Order')[0].strip()
            # print('Order_Date',Order_Date)

            Status = details_1.split('Status:')[1].split('Tracking')[0].strip()
            # print('Status',Status)
            title = details_2.split('Subtotal')[1].split('SKU')[0].strip()
            # print('title', title)

            SKU = details_2.split('SKU:')[1].split('\n')[0].strip()
            print('SKU', SKU)
            print(details_2)
        except Exception as e:
            print(e)

        try:
            dd = details_2.split('Order Received')[1].split(' ')[0].strip()
            print(dd)
            kk = dd.split('\n')
            print(kk)
            quantity = kk[0]
        except Exception as e:
            print(e)

        try:
            price = kk[1]
            subtotal = kk[2]
            print('quantity', quantity)
            print('price', price)
            print('subtotal', subtotal)
        except Exception as e:
            print(e)


            # if (i % 20 == 0):
            #     driver.find_element_by_xpath("/html/body/div[2]/div[2]/div/div[3]/div/div[2]/div/div[1]/div[3]/div/div/div[1]/span[2]/a[2]").click()
            #     driver.implicitly_wait(2)
            #     n = results - 19
            #
            #     for k in range(1, n):
            #         ii = str(k)
            #         print(k)
            #         product_path = '/html/body/div[2]/div[2]/div/div[3]/div/div[2]/div/div[1]/div[3]/div/div/table/tbody[3]/tr[' + ii + ']/td[1]/a'
            #         driver.implicitly_wait(1)
            #         xpath = driver.find_element_by_xpath(product_path)
            #         driver.implicitly_wait(2)
            #         xpath.click()
            #         driver.implicitly_wait(2)
            #         details_4 = driver.find_element_by_class_name("order_details_my_account").text
            #         details_5 = driver.find_element_by_class_name("shopcart_fullView").text
            #         key2 = details_4[details_4.find("Order Number: ") + 14:].split()[0]
            #         value2 = details_4 + details_5
            #         data_2 = key2 +'-'+ value2
            #         list_1.append(data_2)
            #         driver.back()
            #         driver.implicitly_wait(2)
            #         driver.find_element_by_xpath("/html/body/div[2]/div[2]/div/div[3]/div/div[2]/div/div[1]/div[3]/div/div/div[1]/span[2]/a[2]").click()
            #         driver.implicitly_wait(2)
        try:
            y = 2 + i
            sheet1.write(y, 0, Order_Number)
            sheet1.write(y, 1, Order_Date)
            sheet1.write(y, 2, Status)
            sheet1.write(y, 3, title)
            sheet1.write(y, 4, SKU)
            sheet1.write(y, 5, quantity)
            sheet1.write(y, 6, price)
            sheet1.write(y, 7, subtotal)
        except Exception as e:
            print(e)


        finally:
            wb.save('BassPro_JAYBIMBAUM.xls')
            driver.back()
            time.sleep(5)
            # break


basspro()

