from selenium import webdriver
import time
import csv
from selenium.webdriver.chrome.options import Options
from selenium.webdriver import Firefox
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.wait import WebDriverWait
import re
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from xlrd import open_workbook
from xlwt import Workbook
from xlutils.copy import copy
import xlwt
from xlwt import Workbook

options = webdriver.FirefoxOptions()
options.add_argument('-headless')
print("Headless Chrome Initialized on Windows OS")
# driver = webdriver.Firefox(options=options)
driver = webdriver.Chrome()

def Target():
    url = "https://www.target.com/"
    driver.get(url)
    driver.implicitly_wait(5)
    driver.find_element_by_id("account").click()
    time.sleep(3)
    driver.find_element_by_id("accountNav-signIn").click()
    time.sleep(2)
    # driver.find_element_by_id("username").send_keys("aberahim179@gmail.com")
    # driver.implicitly_wait(1)
    # driver.find_element_by_id("password").send_keys("april23rd")
    # driver.implicitly_wait(1)
    # driver.find_element_by_id("login").click()

    driver.refresh()
    time.sleep(20)
    wb = Workbook()
    sheet1 = wb.add_sheet('Sheet 1')

    # rb = open_workbook("target_samuel.xls")
    # wb = copy(rb)


    sheet1 = wb.get_sheet(0)

    sheet1.write(0, 0, 'Order_no')
    sheet1.write(0, 1, 'Cart_total')
    sheet1.write(0, 2, 'Title')
    sheet1.write(0, 3, 'Shipping_cost')
    sheet1.write(0, 4, 'Tax_cost')
    sheet1.write(0, 5, 'Subtotal')
    sheet1.write(0, 6, 'Placed_on')
    sheet1.write(0, 7, 'Delivered_Date')
    sheet1.write(0, 8, 'Quantity')
    sheet1.write(0, 9, 'Adderss')
    sheet1.write(0, 10, 'Status')
    sheet1.write(0, 11, 'Price')
    sheet1.write(0, 12, 'Gift_Card_Details')

    order = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div/div[1]/ul/li[6]/a")))
    order.click()

    for i in range(1,65):


        card_list = []
        print(">>>>>>>>>", i)
        order_no = ' '
        order_total = ' '
        title = ' '
        delivery_charge = ' '
        tax = ' '
        subtotal= ' '
        Placed_on = ' '
        deliverd_on = ' '
        quantity = ' '
        price = ' '
        subtotal = ' '
        addres = ' '
        status = ' '

        if i % 10 == 0:
            try:
                WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, "Button-bwu3xu-0.WFPwc.h-margin-h-default.h-margin-b-jumbo"))).click()
                time.sleep(6)
            except Exception as e:
                print(e)
        try:
            ii = str(i)
            view = '/html/body/div[1]/div/div[5]/div[2]/div/div[1]/div/div[2]/div/div[3]/div/div/div[1]/div[' + ii + ']/div/div[1]/div/div[2]/a'

            view_details = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, view)))

            view_details.click()
            time.sleep(4)


        except Exception as e:
            print(e)
        try:
            stats = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CLASS_NAME, "Col__StyledCol-sc-1c90kgr-0.jlXfMF"))).text

            if (len(stats)) < 12:
                status = "Canceled"
                deliverd_on = ' '
                print('status',status)
                print('deliverd_on',deliverd_on)
            else:
                st = stats.strip().split('\n')
                jj = st[0].split(' ', 1)
                status = jj[0]
                deliverd_on = jj[1]
                print('status',status)
                print('deliverd_on',deliverd_on)
        except Exception as e:
            print(e)


        try:
            addrr = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, "Row-uds8za-0.fLedho.h-hidden-xl-up.h-padding-b-default"))).text
            if addrr is not None:
                add = addrr.strip()
                ad = add.split('to\n')
                addres = ad[1]
                print('address',addres)
        except Exception as e:
            print(e)
        try:
            ord = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, "styles__OrderDetailsInfo-sc-11j55bw-0.MaeSH"))).text

            ordd = ord.strip().split('\n')
            orddee = ordd[0]
            order_no = orddee[1:]
            pla = ordd[1]
            placed = pla.split('on')[1]
            Placed_on = placed.strip()
        except Exception as e:
            print(e)

        try:
            table = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, "styles__StickyContentCard-sc-11j55bw-2.dxzbqd"))).text
        except Exception as e:
            print(e)
        try:
            namee = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, "Col-favj32-0.hfWUvy"))).text
            nam = namee.splitlines()
            title = nam[0]
            quantity = nam[1].replace('Qty', '').strip()
            price = nam[2]
            print('title',title)
            print('quantity',quantity)
            print('price',price)
        except Exception as e:
            print(e)

        try:
            tab1 = table.replace("\nReturns & receipts\nFix an issue", "").strip()
            subtotal = re.search('Subtotal\n(.*)\nShipping', tab1).group(1)
            print('subtotal', subtotal)
            delivery_charge = re.search('Shipping\n(.*)\nTax', tab1).group(1)
            print('delivery_charge', delivery_charge)
            order_total = re.search('Total\n(.*)\nTarget', tab1).group(1)
            print('order_total', order_total)
            tax = re.search('Tax\n(.*)\nTotal', tab1).group(1)
            print('tax', tax)

            tab2 = tab1.split('Gift Card',1)[1].split('\nTarget')
            for m in tab2:
                gc = m.replace("Gift Card ***", "").replace('***','').replace('\n', ':')
                card_list.append(gc)
        except Exception as e:
            print(e)
        try:
            y = 2 + i
            sheet1.write(y, 0, order_no)
            sheet1.write(y, 1, order_total)
            sheet1.write(y, 2, title)
            sheet1.write(y, 3, delivery_charge)
            sheet1.write(y, 4, tax)
            sheet1.write(y, 5, subtotal)
            sheet1.write(y, 6, Placed_on)
            sheet1.write(y, 7, deliverd_on)
            sheet1.write(y, 8, quantity)
            sheet1.write(y, 9, addres)
            sheet1.write(y, 10, status)
            sheet1.write(y, 11, price)


            card_len = len(card_list)
            if card_len > 0 :
                for j in range(card_len):
                    h = 12+ j
                    sheet1.write(y, h, card_list[j])
        except Exception as e:
            print(e)
        finally:
            wb.save('target_aberahim.xls')
            driver.back()
            driver.implicitly_wait(5)


Target()